"""
Basic example using Abrasio in local (free) mode with Patchright.

This example demonstrates how to use Abrasio with maximum anti-detection:
- Uses Patchright (undetected Playwright fork)
- Uses real Chrome (channel="chrome")
- Uses persistent context for better fingerprint
- No custom user_agent (creates fingerprint mismatch)
- No viewport override (no_viewport for realistic behavior)

Before running:
    pip install abrasio
    patchright install chrome  # Install real Chrome, not Chromium
"""

import asyncio
from abrasio import Abrasio
from abrasio.utils import (
    human_click,
    human_type,
    human_scroll,
    human_move_to,
    human_wait,
    simulate_reading,
    random_delay,
)

async def main():
    # Local mode - no API key needed
    # headless=False recommended for maximum stealth

    async with Abrasio(api_key ="sk_live_J3x6He9d35C1tCSt2mmuOtcNIFk_rVtwWdU-R_donSo",
                    #api_key="sk_live_v9mZmBNvZHwblE7-hOwCQ3xgyFE7oeo0kTSu8Nt6p34",
                    region="BR",
                    proxy={"server": "http://network.joinmassive.com:65534", "username": "mpuW15al5h-country-BR-subdivision-SP", "password": "moS1BoA2RbKFIwu9BUr0"},
                    humanize=True,
                    headless=False
                    ) as browser:
        page = await browser.new_page()

        # Test against bot detection sites
        print("Testing against bot detection...")

        # await page.goto("https://www.gov.br")
        # await human_wait(10, 15)
        # await page.wait_for_timeout(3000)
        # await page.screenshot(path="gov.png", full_page=True)
        # print("gov test saved to gov.png")
        
        # Test 1: recaptcha
        await page.goto("https://recaptcha-demo.appspot.com/recaptcha-v3-request-scores.php")
        await human_wait(30, 45)
        await page.wait_for_timeout(3000)
        await page.screenshot(path="recaptcha.png", full_page=True)
        print("recaptcha test saved to recaptcha.png")
        # Test 1: browserscan
        await page.goto("https://browserscan.net")
        await human_wait(10, 15)
        await page.wait_for_timeout(3000)
        await page.screenshot(path="browserscan.png", full_page=True)
        print("browserscan test saved to browserscan.png")

        await page.goto("https://bot.sannysoft.com/")
        await human_wait(10, 15)
        await page.wait_for_timeout(3000)
        await page.screenshot(path="test_sannysoft.png", full_page=True)
        print("Sannysoft test saved to test_sannysoft.png")

        # Test 2: Fingerprint.com (BotD)
        await page.goto("https://demo.fingerprint.com/playground")
        await human_wait(10, 15)
        await page.screenshot(path="test_fingerprint.png", full_page=True)
        print("Fingerprint.com test saved to test_fingerprint.png")

        # Test 3: CreepJS
        await page.goto("https://abrahamjuliot.github.io/creepjs/")
        await human_wait(10, 15)
        await page.screenshot(path="test_creepjs.png", full_page=True)
        print("CreepJS test saved to test_creepjs.png")

        print("\nCheck the screenshots to verify anti-detection is working!")
        print("Green = pass, Red = fail")

        # Keep browser open for manual inspection
        input("\nPress Enter to close browser...")


if __name__ == "__main__":
    asyncio.run(main())
