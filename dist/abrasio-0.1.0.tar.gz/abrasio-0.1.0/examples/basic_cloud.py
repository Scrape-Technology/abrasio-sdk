"""
Basic example using Abrasio in cloud (paid) mode.

This example demonstrates how to use Abrasio with the cloud browser
service using an API key.

Before running:
    pip install abrasio
    export ABRASIO_API_KEY=sk_live_xxx
"""

import asyncio
import os
import time
from abrasio import Abrasio, FingerprintConfig, AbrasioConfig
from abrasio.utils import human_scroll, human_wait, simulate_reading, human_click, human_type


async def main():
    # Get API key from environment
    api_key = "sk_live_J3x6He9d35C1tCSt2mmuOtcNIFk_rVtwWdU-R_donSo"#"sk_live_Qct3WeYuLhXRxPJdLpP2X8X0YqCwUyLUhPywXwmBsyk"#os.getenv("ABRASIO_API_KEY")
    if not api_key:
        print("Set ABRASIO_API_KEY environment variable to use cloud mode")
        print("Example: export ABRASIO_API_KEY=sk_live_xxx")
        return
    config:AbrasioConfig = FingerprintConfig(
        webgl=True,
        webrtc=True,
        )
    # Cloud mode - with API key and region
    # For local testing use: api_url="http://localhost:8000"
    async with Abrasio(
        api_key=api_key,
        # api_url="http://localhost:8000",  # Uncomment for local testing
        region="br",
        url="https://google.com.br",
        proxy=None,
          # Disable WebGL and Canvas for testing
        device="desktop",
        
        #headless=False
    ) as browser:
        page = await browser.new_page()
        # Live view URL (if enabled on server)
        if browser.live_view_url:
            print(f"Watch live: {browser.live_view_url}")

        # Navigate to a page
        await page.goto("https://coveryourtracks.eff.org/")
        await human_wait(100, 130)  # Wait for page to load
        await page.goto("https://uber.com", wait_until="domcontentloaded")
        print(page.url)
        await page.screenshot(path="loadpage.png", full_page=True)
        await page.wait_for_selector("//*[contains(text(), 'Log in')]")
        await human_click(page, "//*[contains(text(), 'Log in')]")
        await human_wait(3, 6)  # Wait for login modal to appear
        # Get page title
        await page.wait_for_selector("#PHONE_NUMBER_or_EMAIL_ADDRESS")
        await page.screenshot(path="login.png", full_page=True)
        await human_click(page, "#PHONE_NUMBER_or_EMAIL_ADDRESS")
        await human_type(page, "jvosobhie@gmail.com", "#PHONE_NUMBER_or_EMAIL_ADDRESS")
        await human_click(page, "//*[contains(text(), 'Continuar')]")
        await page.screenshot(path="otp.png", full_page=True)
        print(await page.content())
        try:
            x = await page.frame("game-core-frame").locator("//*[contains(text(), 'Iniciar desafio')]").click()
            await page.screenshot(path="desafio.png", full_page=True)
            await human_click(page, x= x["x"], y= x["y"])
        except:
            print("Timeout waiting for 'Iniciar desafio' selector")
        await page.screenshot(path="desafiook.png", full_page=True)
        telefone = input("Enter the OTP sent to your email: ")
        await human_type(page, telefone, '#wrapper > div.aq.ar.as.at > div > div > div > div:nth-child(1) > div.ae.af.es > div > div > div:nth-child(1)')
        try:
            await page.wait_for_selector("#PASSWORD")
            await human_click(page, "#PASSWORD")
            await human_type(page, "Ovalle#442", "#PASSWORD")
            await page.screenshot(path="senha.png", full_page=True)
            await human_click(page, "//*[contains(text(), 'Avançar')]")
        except:
            print("Timeout waiting for #PASSWORD selector")
        await page.screenshot(path="loginfeito.png", full_page=True)
        await human_wait(5, 10)  # Wait for login to complete
        await page.goto("https://m.uber.com/go/home", wait_until="domcontentloaded")
        await page.screenshot(path="home.png", full_page=True)
        await page.wait_for_selector("#wrapper > div.css-dqxzrQ > div > main > div > section > div > div > section > div.css-kappr > div > div.css-iBcnDJ > div.css-hSRbgy > ul > li:nth-child(1) > div > div.css-hSpIzb > div > div.css-gvRkiA")
        await human_click(page, "#wrapper > div.css-dqxzrQ > div > main > div > section > div > div > section > div.css-kappr > div > div.css-iBcnDJ > div.css-hSRbgy > ul > li:nth-child(1) > div > div.css-hSpIzb > div > div.css-gvRkiA")  
        await human_type(page, "Internacional", "#wrapper > div.css-dqxzrQ > div > main > div > section > div > div > section > div.css-kappr > div > div.css-iBcnDJ > div.css-hSRbgy > ul > li:nth-child(1) > div > div.css-hSpIzb > div > div.css-gvRkiA")
        await human_click(page, "#wrapper > div.css-dqxzrQ > div > main > div > section > div > div > section > div.css-kappr > div > div.css-iBcnDJ > div.css-hSRbgy > ul > li:nth-child(2) > div > div.css-kAbTNm > div")
        await human_type(page, "Club Severino", '#wrapper > div.css-dqxzrQ > div > main > div > section > div > div > section > div.css-kappr > div > div.css-iBcnDJ > div.css-hSRbgy > ul > li:nth-child(2) > div > div.css-kAbTNm > div')
        await human_click(page, "//*[contains(text(), 'Pesquisar')]")
        await human_wait(7, 15)  # Wait for search results
        await page.screenshot(path="uber_search.png", full_page=True)
        


if __name__ == "__main__":
    asyncio.run(main())
